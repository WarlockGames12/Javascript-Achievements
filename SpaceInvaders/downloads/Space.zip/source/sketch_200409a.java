import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_200409a extends PApplet {

//main file
ArrayList bullets;
ArrayList enemies;
 
int numCol = 10;
Player player1;
Enemy testEnemy;
boolean keyAPressed = false, keyDPressed = false;
PImage alienImage1;
public void setup() {
  
  imageMode(CENTER);
  alienImage1 = loadImage("data/alien1.png");
  startGame();
}
 
public void startGame(){
  player1 = new Player();
  bullets = new ArrayList();
  enemies = new ArrayList();
  generateEnemies(); 
}
 
public void draw() {
  background(0);
  if (player1.lives <= 0){
    startGame();
  }
  showLives();
  player1.display();
  movePlayer1();
  player1.hitCheck();
  handleEnemies();
  handleBullets();
}
 
public void checkEnemiesWall(){
  boolean anyTouchingWall = false;
  for (int i = 0; i < enemies.size(); i++){
    Enemy enemy = (Enemy) enemies.get(i);
//    if (    
  }
}
 
 
public void showLives(){
  for (int i = 0; i <= player1.lives; i++){
    rect(width-40*i, 10, 30, 30);
  } 
}
 
public void generateEnemies() {
  for (int i = 0; i < 20; i++) {
    float x = width*.1f + i%numCol*50;
    float y = 60 + PApplet.parseInt(i/numCol)*60 ;
    enemies.add(new Enemy(x, y));
  }
}
 
public void handleEnemies() {
  for (int i = 0; i < enemies.size(); i++) {
    Enemy enemy = (Enemy) enemies.get(i);
    enemy.move();
    enemy.display();
    enemy.hitCheck();
    if (random(1) > .995f) {
      enemy.shoot();
    }
  }
}
 
 
public void handleBullets() {
  for (int i = 0; i < bullets.size(); i++) {
    Bullet b = (Bullet) bullets.get(i);
    b.move();
    b.display();
  }
}
 
public void movePlayer1() {
  if (keyAPressed) {
    player1.x -=10;
  }
  if (keyDPressed) {
    player1.x +=10;
  }
}
 
public void keyPressed() {
  if (key == 'a') {
    keyAPressed = true;
  }
  else {
    if (key == 'd') {
      keyDPressed = true;
    }
    else {
      if (key == ' ') {
        player1.shoot();
      }
    }
  }
}
 
public void keyReleased() {
  if (key == 'a') {
    keyAPressed = false;
  }
  else {
    if (key == 'd') {
      keyDPressed = false;
    }
  }
}  
 
//Bullet
 
//Bullet
class Bullet {
  float x, y;
  float velocity;
 
  Bullet(float x, float y, float velocity) {
    this.x = x;
    this.y = y;
    this.velocity = velocity;
  }
   
  public void display(){
    rect(this.x, this.y, 5,20);
  }
   
  public void move(){
    this.y+=this.velocity;
    if (this.y > height || this.y < 0){
      bullets.remove(this);
    }
  }
}
 
//Enemy
 
//Enemy
 
class Enemy {
  float x, y;
  float velocity;
  PImage img;
  Enemy(float x, float y) {
    this.x = x;
    this.y = y;
    this.velocity = 5;
    this.img = alienImage1;
  }
 
  public void display() {
    ellipse(this.x, this.y, 30, 30);
    image(img, this.x, this.y);
  }
 
  public void move() {
    this.x+=this.velocity;
    if (this.x > width*.9f) {
      this.x = width*.9f;
      this.velocity *= -1;
      this.y+=30;
    }
 
    if (this.x < width*.1f) {
      this.velocity*=-1;
      this.x = width*.1f;
      this.y+=30;
    }
  }  
   
  public void shoot(){
    Bullet b = new Bullet(this.x, this.y, 5);
    bullets.add(b);
  }
 
  public void hitCheck() {
    for (int i = 0; i < bullets.size(); i++){
      Bullet b = (Bullet) bullets.get(i);      
      float distBetween = dist(b.x, b.y, this.x, this.y);
      if (distBetween < 15 && b.velocity < 0){
        enemies.remove(this);
        bullets.remove(b);
      }
    }
  }
}
 
//Geometry
 
public boolean rectIntersect(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2) {
 
  float[] r1 = new float[8];
  float[] r2 = new float[8];
 
   r1[0] = x1;
   r1[1] = y1;
   r1[2] = x1+w1;
   r1[3] = y1+h1;
   r1[4] = r1[0];
   r1[5] = r1[3];
   r1[6] = r1[2];
   r1[7] = r1[1];
 
   r2[0] = x2;
   r2[1] = y2;
   r2[2] = x2+w2;
   r2[3] = y2+h2;
   r2[4] = r2[0];
   r2[5] = r2[3];
   r2[6] = r2[2];
   r2[7] = r2[1];
   
  boolean intersect = false;
   
  for (int i = 0; i < 8; i=i+2){
    if (pointInRectangle(r2[0], r2[2], r2[1], r2[3], r1[i], r1[i+1])){
    intersect = true;
    }
  }
   
  for (int i = 0; i < 8; i=i+2){
    if (pointInRectangle(r1[0], r1[2], r1[1], r1[3], r2[i], r2[i+1])){
    intersect = true;
    }
  }
  return intersect;
}
 
public boolean isBetween(float v1, float v2, float test) {
  if (test < v1 && test > v2) {
    return true;
  }
  else {
    if (test > v1 && test < v2) {
      return true;
    }
    else {
      return false;
    }
  }
}
 
public boolean pointInRectangle(float x1, float x2, float y1, float y2, float xT, float yT) {
  if (((xT < x1 && xT > x2) || (xT > x1 && xT < x2)) && 
    ((yT < y1 && yT > y2) || (yT > y1 && yT < y2))) {
    return true;
  }
  else {
    return false;
  }
}
 
 
//Player
 
//Player
 
class Player {
  float x, y;
  int lives;
  int score;
  boolean canShoot;
  int timeLastShot;
  int coolDown;
 
  Player() {
    this.x = width/2;
    this.y = height-50;
    this.lives = 3;
    this.timeLastShot = 0;
    this.coolDown = 200;
  }
 
  public void display() {
    rect(this.x, this.y, 30, 30);
  }
 
  public void shoot() {
    if (millis() - timeLastShot > coolDown) {
      Bullet bullet = new Bullet(this.x+12.5f, this.y, -5);
      bullets.add(bullet);
      timeLastShot = millis();
    }
  }
 
  public void hitCheck() {
    for (int i = 0; i < bullets.size(); i++) {
      Bullet b = (Bullet) bullets.get(i);
      float distBetween = dist(b.x, b.y, this.x, this.y);
      if (b.velocity > 0 && rectIntersect(this.x, this.y, 30, 30, b.x, b.y, 5, 20)) {
        this.die();
        bullets = new ArrayList();
      }
    }
  }
 
  public void die() {
    this.x = width/2;
    this.lives--;
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_200409a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
